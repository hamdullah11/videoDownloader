// const Credentials = {
//   user: "TSMT",
//   password: "OaMTqTcWlCuk1esd",
//   database: "timesheet-management-tool",
// };
const Credentials = {
  user: "adil",
  password: "Z76AWvRuEF7Tp0zL",
  database: "timesheet-management-tool",
};

export default Credentials;
